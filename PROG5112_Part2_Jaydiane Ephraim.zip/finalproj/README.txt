PROG5121 / PROG5112 - Part 2: QuickChat

Student: Jaydiane Ephraim

Files:
- src/main/java/Login.java       Reused login functionality from Part 1.
- src/main/java/Message.java     Message validation, ID, hash and display methods.
- src/main/java/QuickChat.java   Main menu, loops, sending, storing and totals.
- src/test/java/MessageTest.java Automated JUnit 5 tests.
- .github/workflows/testJava.yml GitHub Actions workflow for the tests.
- pom.xml                         Maven/JUnit configuration.

Run:
1. Open the folder as a Maven project in NetBeans or another Java IDE.
2. Run QuickChat.java.
3. Run the JUnit tests from the test folder.
4. Push the complete project to GitHub, including the .github/workflows/testJava.yml file.
