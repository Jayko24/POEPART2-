import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Main QuickChat application for Part 2.
 * The menu uses a while loop and the message entry uses a for loop.
 */
public class QuickChat {
    private static final List<Message> messages = new ArrayList<>();
    private static int totalMessages = 0;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        // Reuse the login functionality from Part 1.
        System.out.println("===== QuickChat Login =====");
        System.out.print("Register username: ");
        String username = scanner.nextLine();
        System.out.print("Register password: ");
        String password = scanner.nextLine();

        if (!login.registerUser(username, password)) {
            System.out.println("Registration failed.");
            return;
        }

        System.out.print("Login username: ");
        String loginUsername = scanner.nextLine();
        System.out.print("Login password: ");
        String loginPassword = scanner.nextLine();

        if (!login.loginUser(loginUsername, loginPassword)) {
            System.out.println("Login failed. You cannot send messages.");
            return;
        }

        System.out.println("Welcome to QuickChat.");
        int numberOfMessages = readNumberOfMessages(scanner);

        boolean running = true;
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            String option = scanner.nextLine();

            switch (option) {
                case "1":
                    addMessages(scanner, numberOfMessages);
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please choose 1, 2 or 3.");
            }
        }

        System.out.println("Total number of messages sent: " + returnTotalMessages());
        scanner.close();
    }

    /** Reads the number of messages the user wants to enter. */
    private static int readNumberOfMessages(Scanner scanner) {
        while (true) {
            System.out.print("How many messages would you like to enter? ");
            try {
                int number = Integer.parseInt(scanner.nextLine());
                if (number > 0) {
                    return number;
                }
            } catch (NumberFormatException ignored) {
                // Invalid input is handled below.
            }
            System.out.println("Please enter a valid positive number.");
        }
    }

    /**
     * Adds exactly the requested number of message attempts using a for loop.
     * The loop counter is used as the message number.
     */
    private static void addMessages(Scanner scanner, int numberOfMessages) {
        for (int messageNumber = 0; messageNumber < numberOfMessages; messageNumber++) {
            System.out.println("\n===== Message " + (messageNumber + 1) + " =====");

            String recipient = readRecipient(scanner);
            String text = readMessage(scanner);
            Message message = new Message(messageNumber, recipient, text);

            System.out.println("Message ID: " + message.getMessageID());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Message: " + message.getMessage());

            String option = readMessageAction(scanner);
            String result = SentMessage(message, option);
            System.out.println(result);

            if ("1".equals(option)) {
                messages.add(message);
                totalMessages++;
            } else if ("3".equals(option)) {
                storeMessage(message);
                messages.add(message);
            } else if ("2".equals(option)) {
                System.out.println("Press 0 to delete the message.");
                String delete = scanner.nextLine();
                if (!"0".equals(delete)) {
                    System.out.println("Message was not deleted.");
                }
            }
        }
    }

    /** Validates the recipient until a correctly formatted international number is entered. */
    private static String readRecipient(Scanner scanner) {
        while (true) {
            System.out.print("Enter recipient number: ");
            String recipient = scanner.nextLine();
            Message check = new Message(0, recipient, "check");
            String result = check.checkRecipientCell();
            if ("Cell phone number successfully captured.".equals(result)) {
                return recipient;
            }
            System.out.println(result);
        }
    }

    /** Validates that a message is no more than 250 characters. */
    private static String readMessage(Scanner scanner) {
        while (true) {
            System.out.print("Enter your message: ");
            String text = scanner.nextLine();
            if (text.length() <= 250) {
                System.out.println("Message ready to send.");
                return text;
            }
            System.out.println("Message exceeds 250 characters by "
                    + (text.length() - 250) + " characters; please reduce the size.");
        }
    }

    /** Displays the three message actions required by the assignment. */
    private static String readMessageAction(Scanner scanner) {
        while (true) {
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message");
            System.out.print("Choose an option: ");
            String option = scanner.nextLine();
            if (option.equals("1") || option.equals("2") || option.equals("3")) {
                return option;
            }
            System.out.println("Invalid option. Please choose 1, 2 or 3.");
        }
    }

    /** Processes the selected Send, Disregard or Store action. */
    public static String SentMessage(Message message, String option) {
        switch (option) {
            case "1":
                return "Message successfully sent.";
            case "2":
                return "Press 0 to delete the message.";
            case "3":
                return "Message successfully stored.";
            default:
                return "Invalid message option.";
        }
    }

    /** Displays all messages currently held by the application. */
    public static void printMessages() {
        for (Message message : messages) {
            System.out.println(message.printMessages());
            System.out.println();
        }
    }

    /** Returns the total number of messages successfully sent. */
    public static int returnTotalMessages() {
        return totalMessages;
    }

    /** Stores a message in a JSON file using basic JSON formatting. */
    public static void storeMessage(Message message) {
        List<Message> toStore = new ArrayList<>(messages);
        if (!toStore.contains(message)) {
            toStore.add(message);
        }

        try (FileWriter writer = new FileWriter("messages.json")) {
            writer.write("[\n");
            for (int i = 0; i < toStore.size(); i++) {
                Message current = toStore.get(i);
                writer.write("  {\n");
                writer.write("    \"messageID\": \"" + escapeJson(current.getMessageID()) + "\",\n");
                writer.write("    \"messageHash\": \"" + escapeJson(current.getMessageHash()) + "\",\n");
                writer.write("    \"recipient\": \"" + escapeJson(current.getRecipient()) + "\",\n");
                writer.write("    \"message\": \"" + escapeJson(current.getMessage()) + "\"\n");
                writer.write("  }" + (i < toStore.size() - 1 ? "," : "") + "\n");
            }
            writer.write("]\n");
        } catch (IOException e) {
            System.out.println("Could not store message: " + e.getMessage());
        }
    }

    /** Escapes characters that have special meaning in JSON strings. */
    private static String escapeJson(String value) {
        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
