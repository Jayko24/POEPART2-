/**
 * Handles the basic user registration and login functionality reused from Part 1.
 */
public class Login {
    private String username;
    private String password;

    /** Checks the username rules from Part 1. */
    public boolean checkUserName(String username) {
        return username != null && username.length() <= 5 && username.contains("_");
    }

    /** Checks the password complexity rules from Part 1. */
    public boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) {
            return false;
        }
        return password.matches(".*[A-Z].*")
                && password.matches(".*[a-z].*")
                && password.matches(".*[0-9].*")
                && password.matches(".*[^A-Za-z0-9].*");
    }

    /** Registers a user when all validation rules are satisfied. */
    public boolean registerUser(String username, String password) {
        if (!checkUserName(username) || !checkPasswordComplexity(password)) {
            return false;
        }
        this.username = username;
        this.password = password;
        return true;
    }

    /** Returns true only when the supplied details match the registered user. */
    public boolean loginUser(String username, String password) {
        return this.username != null && this.password != null
                && this.username.equals(username)
                && this.password.equals(password);
    }

    /** Returns the login status message. */
    public String returnLoginStatus(String username, String password) {
        return loginUser(username, password) ? "Login successful." : "Login failed.";
    }
}
