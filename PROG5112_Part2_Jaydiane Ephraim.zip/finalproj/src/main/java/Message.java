/**
 * Represents one QuickChat message and performs the required message validation
 * and string-manipulation operations.
 */
public class Message {
    private final String messageID;
    private final int messageNumber;
    private final String recipient;
    private final String message;
    private final String messageHash;

    /** Creates a message using the loop counter as its message number. */
    public Message(int messageNumber, String recipient, String message) {
        this.messageNumber = messageNumber;
        this.messageID = generateMessageID();
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    /** Generates a unique ten-digit message ID. */
    private String generateMessageID() {
        long number = 1_000_000_000L + (long) (Math.random() * 9_000_000_000L);
        return String.valueOf(number);
    }

    /** Checks that the generated message ID is exactly ten digits. */
    public boolean checkMessageID() {
        return messageID.matches("\\d{10}");
    }

    /**
     * Checks that the recipient contains an international code.
     * The supplied assignment test data includes a South African number with
     * the +27 international code, so valid international numbers are accepted
     * up to 13 characters including the plus sign.
     */
    public String checkRecipientCell() {
        if (recipient != null && recipient.matches("^\\+[0-9]{8,12}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    /**
     * Creates the required hash from the first two ID digits, message number,
     * first word and last word, using substring and string manipulation.
     */
    public String createMessageHash() {
        String text = message == null ? "" : message.trim();
        String[] words = text.isEmpty() ? new String[0] : text.split("\\s+");

        String firstWord = words.length == 0 ? "" : cleanWord(words[0]);
        String lastWord = words.length == 0 ? "" : cleanWord(words[words.length - 1]);

        return (messageID.substring(0, 2) + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    /** Removes punctuation around words before they are placed in the hash. */
    private String cleanWord(String word) {
        return word.replaceAll("[^A-Za-z0-9]", "");
    }

    /** Returns the status used when a message is ready to be sent. */
    public String SentMessage() {
        return "Message ready to send.";
    }

    /** Displays the message details in the required order. */
    public String printMessages() {
        return "Message ID: " + messageID
                + System.lineSeparator() + "Message Hash: " + messageHash
                + System.lineSeparator() + "Recipient: " + recipient
                + System.lineSeparator() + "Message: " + message;
    }

    /** Returns one for this individual message. */
    public int returnTotalMessages() {
        return 1;
    }

    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getRecipient() { return recipient; }
    public String getMessage() { return message; }
    public String getMessageHash() { return messageHash; }
}
