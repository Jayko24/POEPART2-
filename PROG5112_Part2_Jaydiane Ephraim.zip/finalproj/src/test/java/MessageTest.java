import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/** Automated unit tests for the required Message functionality. */
public class MessageTest {
    @Test
    void messageShouldNotExceed250CharactersSuccess() {
        Message message = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        assertEquals("Message ready to send.", message.SentMessage());
        assertTrue(message.getMessage().length() <= 250);
    }

    @Test
    void messageShouldNotExceed250CharactersFailure() {
        String text = "a".repeat(251);
        assertTrue(text.length() > 250);
        assertEquals(1, text.length() - 250);
    }

    @Test
    void recipientNumberCorrectlyFormatted() {
        Message message = new Message(0, "+27718693002", "Hi Mike");
        assertEquals("Cell phone number successfully captured.", message.checkRecipientCell());
    }

    @Test
    void recipientNumberIncorrectlyFormatted() {
        Message message = new Message(0, "0812345678", "Hi Mike");
        assertEquals("Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.", message.checkRecipientCell());
    }

    @Test
    void messageHashIsCreatedCorrectly() {
        Message message = new Message(0, "+27718693002", "Hi Mike, can you join us for dinner tonight?");
        String expected = message.getMessageID().substring(0, 2) + ":0:HITONIGHT";
        assertEquals(expected, message.createMessageHash());
    }

    @Test
    void messageIdIsCreatedUsingTenDigits() {
        Message message = new Message(0, "+27718693002", "Hi Mike");
        assertTrue(message.checkMessageID());
        assertEquals(10, message.getMessageID().length());
    }

    @Test
    void sendMessageOption() {
        Message message = new Message(0, "+27718693002", "Hi Mike");
        assertEquals("Message successfully sent.", QuickChat.SentMessage(message, "1"));
    }

    @Test
    void disregardMessageOption() {
        Message message = new Message(1, "+27718693002", "Hi Mike");
        assertEquals("Press 0 to delete the message.", QuickChat.SentMessage(message, "2"));
    }

    @Test
    void storeMessageOption() {
        Message message = new Message(2, "+27718693002", "Hi Mike");
        assertEquals("Message successfully stored.", QuickChat.SentMessage(message, "3"));
    }
}
